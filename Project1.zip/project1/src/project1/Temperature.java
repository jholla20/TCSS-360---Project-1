package project1;

/**
 * 
 * @author Ford
 *
 */
public class Temperature {

    private double myTemp;

    public Temperature(final int theTemp) {
        this.myTemp = theTemp;
    }

    public double getMyTemp() {
        return this.myTemp / 10;
    }

    public void setMyTemp(final int myTemp) {
        this.myTemp = myTemp;
    }

}