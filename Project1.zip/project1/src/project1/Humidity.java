package project1;

/**
 * 
 * @author Ford
 *
 */
public class Humidity {
    /* private static int[] ACCURACY = {3, 5}; */

    private double myHumid;

    public Humidity(final int theHumid) {
        this.myHumid = theHumid;
    }

    public double getMyHumid() {
        return myHumid / 10;
    }

    public void setMyHumid(double myHumid) {
        this.myHumid = myHumid;
    }
}
