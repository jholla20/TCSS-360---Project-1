package project1;

public class Rain {
    private double myRain;

    private double myRainRate;

    public Rain(final double theRain, final double theRainRate) {
        this.myRain = theRain;
        this.myRainRate = theRainRate;
    }

    public double getMyRainRate() {
        return myRainRate;
    }

    public void setMyRainRate(int myRainRate) {
        this.myRainRate = myRainRate;
    }

    public double getMyRain() {
        return this.myRain;
    }

    public void setMyRain(int myRain) {
        this.myRain = myRain;
    }
}
