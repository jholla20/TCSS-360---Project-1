package project1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class SensorTester {
    public static void main(String[] args) {

        // Change to directory to work with in your computer
        File test1 = new File("src/OutSide.txt");

        //run
        SensorTester test = new SensorTester();
        try {
            test.readTxt(test1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * read a line from a txt file, data is split by ","
     * Create a new object of the sensor class file with data.
     * @param theFile
     * @throws Exception
     */
    public void readTxt(final File theFile) throws Exception {
        try {
            BufferedReader rdr = new BufferedReader(new FileReader(theFile));
            String data;
            while ((data = rdr.readLine()) != null) {
                String[] arrData = data.split(",", 8);
                for (int i = 0; i < data.length(); i++) {
                    switch (i) {
                        case 0:
                            Temperature temp = new Temperature(Integer.valueOf(arrData[i]));
                            System.out.println("Temperature: " + temp.getMyTemp() + " \u00B0F");
                            break;
                        case 1:
                            Wind Win = new Wind(Integer.valueOf(arrData[i]), Integer.valueOf(arrData[i+1]));
                            System.out.println("Wind Direction: " + Win.getMyDirection() + " \u00B0" 
                                                + Win.getMyStringDirection()
                                                + "\nWind Speed: " + Win.getMyWindSpeed() + " mph");
                            break;
                        case 3:
                            Rain rain = new Rain(Double.valueOf(arrData[i]), Double.valueOf(arrData[i+1]));
                            System.out.println("Daily Rain: " + rain.getMyRain() + " in \nRain Rate: " + rain.getMyRainRate() + " in/hr");
                            break;
                        case 5:
                            Barometer baro = new Barometer(Integer.valueOf(arrData[i]), 
                                                            Double.valueOf(arrData[i+1]));
                            System.out.println("Elevation: " + baro.getMyElevation() + " ft \nBarometer: " + baro.getMyBaroPressure() + " Hg");
                            break;
                        case 7:
                            Humidity humi = new Humidity(Integer.valueOf(arrData[i]));
                            System.out.println("Humidity: " + humi.getMyHumid() + "%");
                            break;
                            
                    }
                }
                System.out.println();
                Thread.sleep(5 * 1000); // runs while loop once every 5s
            }
            rdr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
