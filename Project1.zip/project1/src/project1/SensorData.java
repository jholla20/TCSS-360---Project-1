package project1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Random;

/**
 * Simulates the gathering of data by the sensors of the ISS and Envoy and sends
 * them to a text file to be later read by the ISS and Envoy objects.
 * 
 * @author Jordan Holland
 */
public class SensorData {	
	/** Current outdoor temperature. */
	private int myTempOut;
	/** Current outdoor humidity. */
	private int myHumidityOut;
	/** Current direction the wind is blowing. */
	private int myWindDirection;
	/** Current speed of the wind. */
	private int myWindSpeed;
	/** Current amount of rain fallen today. */
	private int myDailyRain;
	/** Rate of rain inches per hour. */
	private int myRainRate;
	/** Current barometric pressure of the air. */
	private int myBarometric = 16;
	/** Current elevation of the sensor. */
	private int myElavation;
	/** Printstream used to write to the outfile. */
	private PrintStream myOutStream;
	/** The out file containing all generated sensor data. */
	private File myOutfile;
	/** The random generator used to produce censor data. */
	private Random myRanGen = new Random();
		
	/**
	 * Default constructor for this object with all values produced.
	 */
	public SensorData() {
		produceValues();
		createOutfile();
	}
	
	/**
	 * Generates a new set of values to be sent into the output text file.
	 */
	protected void readNewValues() {
		produceValues();
		String data = "";
		data += myTempOut + "," + myWindDirection + "," + myWindSpeed + "," + myDailyRain + ",";
		data += myRainRate + "," + myElavation + "," + myBarometric + "," + myHumidityOut;
		System.out.println(data);
	}
	
	
	/**
	 * Private helper method to initialize the values of sensor data.
	 */
	private void produceValues() {
		myWindDirection = myRanGen.nextInt(361);
		if (myWindDirection == 0) {
			myWindDirection++;
		}
		myWindSpeed = myRanGen.nextInt(201);
		myDailyRain = myRanGen.nextInt(100);
		myRainRate = myRanGen.nextInt(31);
		myHumidityOut = myRanGen.nextInt(101);
		if (myHumidityOut == 0) {
			myHumidityOut++;
		}
		myTempOut = myRanGen.nextInt(191) - 40;
		// This number will change once we start working with floats
		myBarometric = myBarometric + myRanGen.nextInt(17);
		myElavation = myRanGen.nextInt(16000) - 999;
	}
	
	/**
	 * Creates a string containing all of the generated sensor data, then
	 * creates an out file with the generated string inside of it
	 */
	private void createOutfile() {
		myOutfile = new File("src/sensordata.txt");
		try {
			myOutStream = new PrintStream(myOutfile);
			String data = "";
			data += myTempOut + "," + myWindDirection + "," + myWindSpeed + "," + myDailyRain + ",";
			data += myRainRate + "," + myElavation + "," + myBarometric + "," + myHumidityOut;
			System.setOut(myOutStream);
			System.out.println(data);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
