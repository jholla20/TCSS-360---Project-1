package project1;

public class SensorDataTester {
	/**
	 * Driver method for the class.
	 * @param theArgs Command line arguments
	 */
	public static void main(String[] theArgs) {
		SensorData test = new SensorData();
		test.readNewValues();
	}
}
