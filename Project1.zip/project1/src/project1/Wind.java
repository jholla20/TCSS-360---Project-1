package project1;

public class Wind {
	  private int myDirection;

	  private String myStringDirection;

	  private int myWindSpeed;

	  public Wind(final int theDirection, final int theWindSpeed) {
	    this.myWindSpeed = theWindSpeed;
	    this.myDirection = theDirection;
	    this.myStringDirection = direction(myDirection);
	  }

	  private String direction(final int theDirection) {
	    StringBuilder str = new StringBuilder();

	    if (theDirection >= 338 || theDirection < 23) {
	      str.append("N");
	    }
	    if (theDirection >= 23 && theDirection < 68) {
	      str.append("NE");
	    }
	    if (theDirection >= 68 && theDirection < 113) {
	      str.append("E");
	    }
	    if (theDirection >= 113 && theDirection < 158) {
	      str.append("SE");
	    }
	    if (theDirection >= 158 && theDirection < 203) {
	      str.append("S");
	    }
	    if (theDirection >= 203 && theDirection < 248) {
	      str.append("SW");
	    }
	    if (theDirection >= 248 && theDirection < 293) {
	      str.append("W");
	    }
	    if (theDirection >= 293 && theDirection < 338) {
	      str.append("NW");
	    }

	    return str.toString();
	  }

	  public void setMyDirection(final int myDirection) {
	    this.myDirection = myDirection;
	  }

	  public int getMyDirection() {
	    return this.myDirection;
	  }

	  public String getMyStringDirection() {
	    return myStringDirection;
	  }

	  public void setMyStringDirection(final String myStringDirection) {
	    this.myStringDirection = myStringDirection;
	  }

	  public int getMyWindSpeed() {
	    return myWindSpeed;
	  }
}
